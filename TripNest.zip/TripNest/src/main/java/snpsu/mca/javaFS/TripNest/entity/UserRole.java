package snpsu.mca.javaFS.TripNest.entity;

public enum UserRole {
    USER,
    ADMIN,
    DRIVER
}